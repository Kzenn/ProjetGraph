#include "Graph.hpp"
#define SCREEN_H 768
#define SCREEN_W 1024

#define TAILLEX 100
#define TAILLEY 100

/// Overload constructor
Graph::Graph()
{
    /// Nothing to do here
}

/// Destructor
Graph::~Graph()
{
    /// Nothing to do here !
}

/// Getter to read "m_order" attribute
unsigned int Graph::getOrder() const
{
    return m_order;
}

/// Getter to read "EdgeTab" attribute
std::vector<Edge>& Graph::getEdgeTab()
{
    return EdgeTab;
}

/// Setter to modify "m_order" attribute
void Graph::setOrder(unsigned int order)
{
    m_order = order;
}

std::vector<Sommet*>& Graph::getSommetTab()
{
    return vecSommet;
}

void Graph::FillVecSommet(Sommet* s)
{
    vecSommet.push_back(s);
}

void Graph::ReadFile(std::string FileName)
{
    ///Lire un fichier ligne par ligne
    ///Entr�e : le chemin d'acc�s au fichier
    std::ifstream fichier(FileName, std::ios::in);


    std::vector<int> temp;
    int num1 = 0;
    int num2 = 0;
    int poids = 0;
    int num_a =0;
    int x1 =0;
    int x2 = 0;
    int y1 =0;
    int y2 = 0;
    int population = 0;
    int population2 = 0;

    Sommet* tri;
    int mem=0;
    std::string Chaine1;
    std::string Chaine2;


    if(fichier) ///test si le fichier est bien ouvert
    {
        while (!fichier.eof())
        {
            BITMAP *pic = nullptr;
            BITMAP *pic2 = nullptr;

            fichier >> num_a >> Chaine1 >> num1 >> num2 >> Chaine2 >>poids >> x1 >> y1 >> x2 >> y2 >> population >> population2;
            std::cout << num1 << " " << Chaine1 << " " << num1 << " "<< num2 << " " << Chaine2 <<" " << poids <<std::endl;
            if(x1<88)
                x1 = 88;
            if(x1+TAILLEX>SCREEN_W)
                x1 = SCREEN_W-TAILLEX;
            if(y1+TAILLEY>SCREEN_H)
                y1 = SCREEN_H-TAILLEY;
            if(y1<0)
                y1 = 0;
            if(x2<88)
                x2 = 88;
            if(x2+TAILLEX>SCREEN_W)
                x2 = SCREEN_W-TAILLEX;
            if(y2+TAILLEY>SCREEN_H)
                y2 = SCREEN_H-TAILLEY;
            if(y2<0)
                y2 = 0;
            pic = load_bitmap(Chaine1.c_str(), NULL);
            pic2 = load_bitmap(Chaine2.c_str(), NULL);
            Sommet *vi = new Sommet(num1,x1,y1,pic, population, Chaine1);
            Sommet *vi2 = new Sommet(num2,x2,y2,pic2, population2, Chaine2);
            Edge *ve = new Edge(vi,vi2,poids,false);
            EdgeTab.push_back(*ve);

            vecSommet.push_back(vi);
            vecSommet.push_back(vi2);

        }


        for(int i=0; i<vecSommet.size(); i++)
        {
            tri = vecSommet[i];
            mem=i;


            for(int i=0; i<vecSommet.size(); i++)
            {
                if(tri->getidx()==vecSommet[i]->getidx())
                {
                    vecSommet.erase(vecSommet.begin()+i);
                }
            }
            vecSommet.push_back(tri);
        }



        fichier.close();
        std::cout << EdgeTab.size() << std::endl;
    }

    else  ///en cas d'erreur...
    {
        std::cout << "Cannot read " << FileName << std::endl;
    }
}
